To compile the file, navigate to this folder in command line, then type 'make'

To run this program, type /5ps.out

This program is able to retrieve the following information to one specified process:
1. The current status of the specified process
2. The time this program has been running on the system
3. The size of the process
4. The virtual memory that the specified process runs
5. Use './5ps.out -h' to print out this information and which commands are retrieve this information