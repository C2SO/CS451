Nicholas Rahbany
CS451
readme.txt

To compile the program, navigate to the directory in the terminal
    and type the command 'make'

To run the command use this example:
    ./A3.out -p 1 -f 10 -w 5 < 'file.txt'
    -p defines the number of people in the program
    -f defines the number of floors the program will accommodate
    -w defines the max wait time on each floors
    'file.txt' is the file your data will come from