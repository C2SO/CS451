How to run A2.c:
    1. Navigate to the directory this is stored in
    2. Run the command 'make'
    3. In the terminal, type './A2.out (name of text file)'

name_of_text_file is defined by you, and is what is going to be looked at.
The first column is the process number
The second column is the time that the process is received
The third column is the number of bursts (seconds) the process needs to run
The fourth column is the priority of the process


I HAVE USED ONE COUPON FOR THIS ASSIGNMENT!